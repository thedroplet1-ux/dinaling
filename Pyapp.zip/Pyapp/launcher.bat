@echo off
setlocal
cd /d "%~dp0"

net session >nul 2>&1
if %errorlevel% NEQ 0 (
    echo [INFO] Requesting standard administrator privileges...
    powershell -Command "Start-Process '%~f0' -Verb RunAs"
    exit /b
)

REM Startup config. These arguments are passed to webremote.exe every time it starts.
REM Examples:
REM   set "APP_ARGS=-cloak"
REM   set "APP_ARGS=-cloudflare"
REM   set "APP_ARGS=-cloudflare -cloak"
REM   set "APP_ARGS=serve --host 0.0.0.0 --port 9090"
set "APP_ARGS=-cloudflare"

set "WEBRD_LAUNCHER=1"
set "EXE=%~dp0\webremote.exe"

if not exist "%EXE%" (
    echo [ERROR] webremote.exe was not found at:
    echo %EXE%
    pause
    exit /b 1
)

:again
"%EXE%" %APP_ARGS% %*
echo.
echo Webremote stopped. Starting it again in 2 seconds...
timeout /t 2 /nobreak >nul
goto again
