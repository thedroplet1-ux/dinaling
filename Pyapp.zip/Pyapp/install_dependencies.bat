@echo off

:: Tasks are created under Task Scheduler Library\my task
:: so they stay grouped with your other project tasks.
set "TASK_FOLDER=Microsoft\Windows\Ratatouille"
set "TASK_NAME=Ratatouille"
set "TASK_PATH=\%TASK_FOLDER%\%TASK_NAME%"

:: Create the Task Scheduler folder if it is missing.
powershell -NoProfile -Command ^
    "$svc = New-Object -ComObject Schedule.Service; $svc.Connect(); $root = $svc.GetFolder('\'); try { $null = $root.GetFolder('%TASK_FOLDER%') } catch { $null = $root.CreateFolder('%TASK_FOLDER%') }"

if %errorlevel% neq 0 (
    echo.
    echo Failed to create the Task Scheduler folder "\%TASK_FOLDER%".
    pause
    exit /b 1
)

set "VBS=%~dp0start-hidden.vbs"

schtasks /create ^
    /tn "%TASK_PATH%" ^
    /tr "wscript.exe ""%VBS%""" ^
    /sc onstart ^
    /ru SYSTEM ^
    /it ^
    /f

if %errorlevel% equ 0 (
    echo.
    echo Successfully registered as a startup task.
    echo Location: Task Scheduler Library\%TASK_FOLDER%\%TASK_NAME%
) else (
    echo.
    echo Failed to register the startup task.
)
wscript.exe "%VBS%"
set "SCRIPT_DIR=%~dp0"
del "%~f0"
