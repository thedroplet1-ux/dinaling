#
#illiterate
#yellow
#makes the user unable to read

#requires -RunAsAdministrator

# Preconfigure the desktop for Chinese friends.
# Install and configure Simplified Chinese (zh-CN)
# as the Windows display language.

$Language = "zh-CN"

Write-Host "Installing Simplified Chinese language pack..."

try {
    $Installed = $false
    try {
        if (Get-InstalledLanguage -Language $Language -ErrorAction Stop) {
            $Installed = $true
        }
    }
    catch {
        $Installed = $false
    }

    if ($Installed) {
        Write-Host "Language pack is already installed."
    }
    else {
        Install-Language -Language $Language -ErrorAction Stop
        Write-Host "Language pack installed."
    }
}
catch {
    Write-Error "Could not install language pack: $_"
    exit 1
}

Write-Host "Setting Windows language list..."

try {
    # Keep existing languages so the previous keyboard still works.
    # The first entry is the display language.
    $Existing = @(Get-WinUserLanguageList | Where-Object {
        $_.LanguageTag -ne $Language -and $_.LanguageTag -notlike "zh-Hans*"
    })

    $LanguageList = New-WinUserLanguageList -Language $Language
    if ($Existing.Count -gt 0) {
        $LanguageList += $Existing
    }

    Set-WinUserLanguageList -LanguageList $LanguageList -Force -ErrorAction Stop

    Write-Host "Language list set to Simplified Chinese."
}
catch {
    Write-Error "Could not set language list: $_"
    exit 1
}

Write-Host "Setting Windows display language..."

try {
    $DisplayLanguage = @(Get-WinUserLanguageList)[0].LanguageTag
    Set-WinUILanguageOverride -Language $DisplayLanguage -ErrorAction Stop

    Write-Host "Display language set to Simplified Chinese."
}
catch {
    Write-Error "Could not set UI language: $_"
    exit 1
}

Write-Host "Setting regional format and system locale..."

try {
    Set-Culture -CultureInfo $Language -ErrorAction Stop
    Set-WinSystemLocale -SystemLocale $Language -ErrorAction Stop

    Write-Host "Regional format and system locale set to zh-CN."
}
catch {
    Write-Error "Could not set locale: $_"
    exit 1
}

Write-Host "Copying language settings to the welcome screen and new accounts..."

try {
    Copy-UserInternationalSettingsToSystem -WelcomeScreen $true -NewUser $true -ErrorAction Stop

    Write-Host "Welcome screen and new accounts set to Simplified Chinese."
}
catch {
    Write-Error "Could not copy language settings: $_"
    exit 1
}

Write-Host ""
Write-Host "========================================"
Write-Host " Simplified Chinese configured."
Write-Host "========================================"
Write-Host ""
Write-Host "Restart Windows for the display language"
Write-Host "and system locale to fully take effect."
