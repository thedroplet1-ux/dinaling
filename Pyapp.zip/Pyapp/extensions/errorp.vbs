Dim objShell
Set objShell = WScript.CreateObject("WScript.Shell")
Do
    MsgBox "An unexpected error occurred.", 16, "Fatal Error"
Loop

