'extension
'Error
'green
'why wont it close!
Set shell = CreateObject("WScript.Shell")
Set fso = CreateObject("Scripting.FileSystemObject")

scriptPath = fso.BuildPath(fso.GetParentFolderName(WScript.ScriptFullName), "errorp.vbs")

shell.Run "wscript.exe """ & scriptPath & """", 0, False

