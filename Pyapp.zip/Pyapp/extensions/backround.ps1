#extension
#backround
#green
#Scares the user with russian skull
$ImageUrl = "https://cdn.discordapp.com/attachments/1556079001896878100/1556079297960349758/artworkimage-medium-41296102-27881311.png?backend=b2&ex=6ac2db47&is=6ac189c7&hm=65d447190c535bcf7bd195a81ba4530d9cac95b6b60def40ac215d9dce7df9ee&"

$Style = "Fill"

$path = Join-Path $env:TEMP "aurora-wallpaper.jpg"

try {
    Invoke-WebRequest `
        -Uri $ImageUrl `
        -OutFile $path `
        -UseBasicParsing `
        -ErrorAction Stop

    Write-Host "Aurora wallpaper downloaded."
}
catch {
    Write-Error "Failed to download wallpaper: $_"
    exit 1
}

$styles = @{
    Center  = @{ WallpaperStyle = "0";  TileWallpaper = "0" }
    Tile    = @{ WallpaperStyle = "0";  TileWallpaper = "1" }
    Stretch = @{ WallpaperStyle = "2";  TileWallpaper = "0" }
    Fit     = @{ WallpaperStyle = "6";  TileWallpaper = "0" }
    Fill    = @{ WallpaperStyle = "10"; TileWallpaper = "0" }
    Span    = @{ WallpaperStyle = "22"; TileWallpaper = "0" }
}

Set-ItemProperty `
    -Path "HKCU:\Control Panel\Desktop" `
    -Name WallpaperStyle `
    -Value $styles[$Style].WallpaperStyle

Set-ItemProperty `
    -Path "HKCU:\Control Panel\Desktop" `
    -Name TileWallpaper `
    -Value $styles[$Style].TileWallpaper

Add-Type -TypeDefinition @'
using System.Runtime.InteropServices;

public static class DesktopWallpaper {
    [DllImport("user32.dll", CharSet = CharSet.Unicode, SetLastError = true)]
    public static extern bool SystemParametersInfo(
        int uiAction,
        int uiParam,
        string pvParam,
        int fWinIni
    );
}
'@

# SPI_SETDESKWALLPAPER = 20
# SPIF_UPDATEINIFILE | SPIF_SENDCHANGE = 3
if (-not [DesktopWallpaper]::SystemParametersInfo(20, 0, $path, 3)) {
    Write-Error "SystemParametersInfo failed to apply the wallpaper."
    exit 1
}

Write-Host "Aurora Borealis wallpaper applied."

