::extension
::Porn
::green
::opens pornhub
@echo off
start "" "https://www.pornhub.com/video/search?search=hotmommy"
start "" "https://www.pornhub.com/video/search?search=gaysex"

