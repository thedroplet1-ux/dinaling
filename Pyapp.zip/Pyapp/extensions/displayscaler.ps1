#extension
#scale
#green
#sets the display scale annoyingly large
$Percent = 600
$DisplayIndex = 0

$steps = @(100, 125, 150, 175, 200, 225, 250, 300, 350, 400, 450, 500, 550, 600)

Add-Type -TypeDefinition @'
using System;
using System.Runtime.InteropServices;

public static class DisplayScale {
    [StructLayout(LayoutKind.Sequential)]
    public struct LUID { public uint LowPart; public int HighPart; }

    [StructLayout(LayoutKind.Sequential)]
    public struct PATH_SOURCE {
        public LUID adapterId;
        public uint id;
        public uint modeInfoIdx;
        public uint statusFlags;
    }

    [StructLayout(LayoutKind.Sequential)]
    public struct RATIONAL {
        public uint Numerator;
        public uint Denominator;
    }

    [StructLayout(LayoutKind.Sequential)]
    public struct PATH_TARGET {
        public LUID adapterId;
        public uint id;
        public uint modeInfoIdx;
        public uint outputTechnology;
        public uint rotation;
        public uint scaling;
        public RATIONAL refreshRate;
        public uint scanLineOrdering;
        public int targetAvailable;
        public uint statusFlags;
    }

    [StructLayout(LayoutKind.Sequential)]
    public struct PATH {
        public PATH_SOURCE sourceInfo;
        public PATH_TARGET targetInfo;
        public uint flags;
    }

    [StructLayout(LayoutKind.Sequential)]
    public struct MODE {
        public uint infoType;
        public uint id;
        public LUID adapterId;
        public ulong d0, d1, d2, d3, d4, d5;
    }

    [DllImport("user32.dll")]
    public static extern int GetDisplayConfigBufferSizes(
        uint flags,
        out uint numPaths,
        out uint numModes
    );

    [DllImport("user32.dll")]
    public static extern int QueryDisplayConfig(
        uint flags,
        ref uint numPaths,
        [Out] PATH[] paths,
        ref uint numModes,
        [Out] MODE[] modes,
        IntPtr topo
    );

    [DllImport("user32.dll")]
    static extern int DisplayConfigGetDeviceInfo(IntPtr requestPacket);

    [DllImport("user32.dll")]
    static extern int DisplayConfigSetDeviceInfo(IntPtr setPacket);

    public static PATH[] GetActivePaths() {
        uint numPaths, numModes;

        if (GetDisplayConfigBufferSizes(2, out numPaths, out numModes) != 0)
            return null;

        var paths = new PATH[numPaths];
        var modes = new MODE[numModes];

        if (QueryDisplayConfig(
            2,
            ref numPaths,
            paths,
            ref numModes,
            modes,
            IntPtr.Zero
        ) != 0)
            return null;

        if (numPaths < paths.Length)
            Array.Resize(ref paths, (int)numPaths);

        return paths;
    }

    public static int GetDpi(
        LUID adapterId,
        uint sourceId,
        out int minRel,
        out int curRel,
        out int maxRel
    ) {
        minRel = curRel = maxRel = 0;

        IntPtr buf = Marshal.AllocHGlobal(32);

        try {
            for (int i = 0; i < 32; i++)
                Marshal.WriteByte(buf, i, 0);

            Marshal.WriteInt32(buf, 0, -3);
            Marshal.WriteInt32(buf, 4, 32);
            Marshal.WriteInt32(buf, 8, (int)adapterId.LowPart);
            Marshal.WriteInt32(buf, 12, adapterId.HighPart);
            Marshal.WriteInt32(buf, 16, (int)sourceId);

            int err = DisplayConfigGetDeviceInfo(buf);

            if (err == 0) {
                minRel = Marshal.ReadInt32(buf, 20);
                curRel = Marshal.ReadInt32(buf, 24);
                maxRel = Marshal.ReadInt32(buf, 28);
            }

            return err;
        }
        finally {
            Marshal.FreeHGlobal(buf);
        }
    }

    public static int SetDpi(
        LUID adapterId,
        uint sourceId,
        int scaleRel
    ) {
        IntPtr buf = Marshal.AllocHGlobal(24);

        try {
            for (int i = 0; i < 24; i++)
                Marshal.WriteByte(buf, i, 0);

            Marshal.WriteInt32(buf, 0, -4);
            Marshal.WriteInt32(buf, 4, 24);
            Marshal.WriteInt32(buf, 8, (int)adapterId.LowPart);
            Marshal.WriteInt32(buf, 12, adapterId.HighPart);
            Marshal.WriteInt32(buf, 16, (int)sourceId);
            Marshal.WriteInt32(buf, 20, scaleRel);

            return DisplayConfigSetDeviceInfo(buf);
        }
        finally {
            Marshal.FreeHGlobal(buf);
        }
    }
}
'@

$paths = [DisplayScale]::GetActivePaths()

if (-not $paths -or $DisplayIndex -ge $paths.Length) {
    Write-Error "No active display at index $DisplayIndex."
    exit 1
}

$path = $paths[$DisplayIndex]

$minRel = 0
$curRel = 0
$maxRel = 0

$err = [DisplayScale]::GetDpi(
    $path.sourceInfo.adapterId,
    $path.sourceInfo.id,
    [ref]$minRel,
    [ref]$curRel,
    [ref]$maxRel
)

if ($err -ne 0) {
    Write-Error "Could not read current scale (error $err)."
    exit 1
}

$recommendedIdx = -$minRel
$targetIdx = [Array]::IndexOf($steps, $Percent)
$targetRel = $targetIdx - $recommendedIdx

if ($targetRel -lt $minRel) {
    $targetRel = $minRel
}

if ($targetRel -gt $maxRel) {
    $targetRel = $maxRel
}

$err = [DisplayScale]::SetDpi(
    $path.sourceInfo.adapterId,
    $path.sourceInfo.id,
    $targetRel
)

if ($err -ne 0) {
    Write-Error "Could not set scale (error $err)."
    exit 1
}

Write-Host "Display $DisplayIndex scale set to 200%."

