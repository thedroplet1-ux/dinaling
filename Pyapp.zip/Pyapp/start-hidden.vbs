Set shell = CreateObject("WScript.Shell")

scriptDir = CreateObject("Scripting.FileSystemObject").GetParentFolderName(WScript.ScriptFullName)
launcher = scriptDir & "\launcher.bat"

shell.Run "cmd.exe /c """ & launcher & """", 0, False

