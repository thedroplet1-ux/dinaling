$ErrorActionPreference = "Stop"

$signature = @"
using System;
using System.Runtime.InteropServices;
public class WebremoteNative {
    [DllImport("kernel32.dll", SetLastError = true)]
    public static extern uint SetErrorMode(uint uMode);
}
"@
Add-Type -TypeDefinition $signature
# Missing-DLL and crash dialogs keep the process alive until someone clicks OK.
# Fail those immediately so the launcher can restore the backup instead.
[WebremoteNative]::SetErrorMode(0x8003) | Out-Null

function Split-CmdArgs([string]$text) {
    if (-not $text) { return @() }
    return @([regex]::Split($text.Trim(), "\s+") | Where-Object { $_ -ne "" })
}

$exe = $env:RUNPY
if (-not $exe) { exit 2 }
if (-not [System.IO.Path]::IsPathRooted($exe)) {
    $cmd = Get-Command $exe -ErrorAction SilentlyContinue
    if (-not $cmd) { exit 2 }
    $exe = $cmd.Source
}

$argList = New-Object System.Collections.Generic.List[string]
if ($env:WEBRD_SPAWN -eq "probe") {
    $argList.Add("-c")
    $argList.Add("import sys; import flask, waitress, pyautogui, mss; from PIL import Image")
} else {
    if (-not $env:APP_SCRIPT) { exit 2 }
    $argList.Add($env:APP_SCRIPT)
    foreach ($extra in @($env:APP_ARGS, $env:WEBRD_USER_ARGS)) {
        foreach ($part in (Split-CmdArgs $extra)) { $argList.Add($part) }
    }
}

$quoted = foreach ($arg in $argList) {
    if ($arg -match "[\s`"]") { '"' + ($arg.Replace('"', '\"')) + '"' } else { $arg }
}

$psi = New-Object System.Diagnostics.ProcessStartInfo
$psi.FileName = $exe
$psi.Arguments = ($quoted -join " ")
$psi.UseShellExecute = $false
$psi.CreateNoWindow = $false
$psi.WorkingDirectory = (Get-Location).Path

$proc = New-Object System.Diagnostics.Process
$proc.StartInfo = $psi
try {
    if (-not $proc.Start()) { exit 2 }
} catch {
    exit 2
}

$limit = 0
if ($env:WEBRD_TIMEOUT) { [void][int]::TryParse($env:WEBRD_TIMEOUT, [ref]$limit) }
if ($limit -gt 0) {
    if (-not $proc.WaitForExit($limit * 1000)) {
        Write-Host "[INFO] Python hung on a startup error. Closing it."
        & taskkill.exe /F /T /PID $proc.Id 2>$null | Out-Null
        exit 2
    }
} else {
    $proc.WaitForExit() | Out-Null
}

if ($proc.ExitCode -eq 0) { exit 0 }
if ($env:WEBRD_SPAWN -eq "probe") {
    Write-Host "[INFO] Python failed to start (exit $($proc.ExitCode))."
}
exit 2
